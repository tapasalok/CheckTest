package com.websystique.springboot.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.websystique.springboot.model.Message;
import com.websystique.springboot.model.SSAP;
import com.websystique.springboot.service.SSAPService;
import com.websystique.springboot.util.CustomErrorType;

@RestController
@RequestMapping("/api")
public class RestApiController {

	public static final Logger logger = LoggerFactory.getLogger(RestApiController.class);

	@Autowired
	SSAPService ssapService; //Service which will do all data retrieval/manipulation work

	// -------------------Retrieve All SSAPs---------------------------------------------

	@RequestMapping(value = "/ssap/", method = RequestMethod.GET)
	public ResponseEntity<List<SSAP>> listAllSSAPs() {
		List<SSAP> ssaps = ssapService.findAllSSAPs();
		if (ssaps.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
			// You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<SSAP>>(ssaps, HttpStatus.OK);
	}

	@RequestMapping(value = "/messages/", method = RequestMethod.GET)
	public ResponseEntity<List<Message>> getMessages() {
//		List<Message> messages = SSAPService.getMessages();
//		if (messages.isEmpty()) {
//			return new ResponseEntity(HttpStatus.NO_CONTENT);
//			// You many decide to return HttpStatus.NOT_FOUND
//		}
//		return new ResponseEntity<List<Message>>(messages, HttpStatus.OK);
		logger.info("Called getMessages : ");
		List<Message> messages = new ArrayList<>();
		Message message = new Message();
		message.setId(1L);
		message.setContent("This is Message Box");
		
		messages.add(message);
		return new ResponseEntity<List<Message>>(messages, HttpStatus.OK);
		 
	}
	
	// -------------------Retrieve Single SSAP------------------------------------------

	@RequestMapping(value = "/ssap/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getSSAP(@PathVariable("id") long id) {
		logger.info("Fetching SSAP with id {}", id);
		SSAP ssap = ssapService.findById(id);
		if (ssap == null) {
			logger.error("SSAP with id {} not found.", id);
			return new ResponseEntity(new CustomErrorType("SSAP with id " + id 
					+ " not found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<SSAP>(ssap, HttpStatus.OK);
	}

	// -------------------Create a SSAP-------------------------------------------

	@RequestMapping(value = "/ssap/", method = RequestMethod.POST)
	public ResponseEntity<?> createSSAP(@RequestBody SSAP ssap, UriComponentsBuilder ucBuilder) {
		logger.info("Creating SSAP : {}", ssap);

//		Removing to add same ssaps for multiple Calls
//		if (SSAPService.isSSAPExist(SSAP)) {
//			logger.error("Unable to create. A SSAP with name {} already exist", SSAP.getName());
//			return new ResponseEntity(new CustomErrorType("Unable to create. A SSAP with name " + 
//			SSAP.getName() + " already exist."),HttpStatus.CONFLICT);
//		}
		ssapService.saveSSAP(ssap);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/api/ssap/{id}").buildAndExpand(ssap.getId()).toUri());
		return new ResponseEntity<String>(headers, HttpStatus.CREATED);
	}

	// ------------------- Update a SSAP ------------------------------------------------

	@RequestMapping(value = "/ssap/{id}", method = RequestMethod.PUT)
	public ResponseEntity<?> updateSSAP(@PathVariable("id") long id, @RequestBody SSAP ssap) {
		logger.info("Updating SSAP with id {}", id);

		SSAP ssapLocal = ssapService.findById(id);

		if (ssapLocal == null) {
			logger.error("Unable to update. SSAP with id {} not found.", id);
			return new ResponseEntity(new CustomErrorType("Unable to upate. SSAP with id " + id + " not found."),
					HttpStatus.NOT_FOUND);
		}

		ssapLocal.setName(ssap.getName());
		ssapLocal.setDate(ssap.getDate());
		ssapLocal.setName(ssap.getName());
		ssapLocal.setSsapScore(ssap.getSsapScore());
		ssapService.updateSSAP(ssapLocal);
		return new ResponseEntity<SSAP>(ssapLocal, HttpStatus.OK);
	}

	// ------------------- Delete a SSAP-----------------------------------------

	@RequestMapping(value = "/ssap/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteSSAP(@PathVariable("id") long id) {
		logger.info("Fetching & Deleting SSAP with id {}", id);

		SSAP ssap = ssapService.findById(id);
		if (ssap == null) {
			logger.error("Unable to delete. SSAP with id {} not found.", id);
			return new ResponseEntity(new CustomErrorType("Unable to delete. SSAP with id " + id + " not found."),
					HttpStatus.NOT_FOUND);
		}
		ssapService.deleteSSAPById(id);
		return new ResponseEntity<SSAP>(HttpStatus.NO_CONTENT);
	}

	// ------------------- Delete All SSAPs-----------------------------

	@RequestMapping(value = "/ssap/", method = RequestMethod.DELETE)
	public ResponseEntity<SSAP> deleteAllSSAPs() {
		logger.info("Deleting All SSAPs");

		ssapService.deleteAllSSAPs();
		return new ResponseEntity<SSAP>(HttpStatus.NO_CONTENT);
	}


}