package com.websystique.springboot.repositories;

import com.websystique.springboot.model.SSAP;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SSAPRepository extends JpaRepository<SSAP, Long> {

    SSAP findByName(String name);

}
