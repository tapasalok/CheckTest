package com.websystique.springboot.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "SSAP")
public class SSAP implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotEmpty
	@Column(name = "NAME", nullable = false)
	private String name;

	@NotEmpty
	@Column(name = "DATE", nullable = false)
	private String date;

	@Column(name = "SSAPSCORE", nullable = false)
	private Double ssapScore;

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Double getSsapScore() {
		return ssapScore;
	}

	public void setSsapScore(Double ssapScore) {
		this.ssapScore = ssapScore;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		SSAP ssap = (SSAP) o;

		if (Double.compare(ssap.ssapScore, ssapScore) != 0)
			return false;
		if (id != null ? !id.equals(ssap.id) : ssap.id != null)
			return false;
		if (name != null ? !name.equals(ssap.name) : ssap.name != null)
			return false;
		if (ssapScore != null ? !ssapScore.equals(ssap.ssapScore) : ssap.ssapScore != null)
			return false;
		if (date != null ? !date.equals(ssap.date) : ssap.date != null)
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		int result;
		long temp;
		result = id != null ? id.hashCode() : 0;
		result = 31 * result + (name != null ? name.hashCode() : 0);
		result = 31 * result + (date != null ? date.hashCode() : 0);
		temp = Double.doubleToLongBits(ssapScore);
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public String toString() {
		return "SSAP [id=" + id + ", name=" + name + ", date=" + date + ", ssapScore=" + ssapScore
				+"]";
	}

}
