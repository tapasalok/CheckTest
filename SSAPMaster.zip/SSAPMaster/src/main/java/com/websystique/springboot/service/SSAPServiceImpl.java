package com.websystique.springboot.service;

import java.util.List;

import com.websystique.springboot.model.SSAP;
import com.websystique.springboot.model.Message;
import com.websystique.springboot.repositories.SSAPRepository;
import com.websystique.springboot.repositories.MessageRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@Service("ssapService")
@Transactional
public class SSAPServiceImpl implements SSAPService{

	@Autowired
	private SSAPRepository ssapRepository;

	@Autowired
	private MessageRepository messageRepository;
	
	public SSAP findById(Long id) {
		return ssapRepository.findOne(id);
	}

	public SSAP findByName(String name) {
		return ssapRepository.findByName(name);
	}

	public void saveSSAP(SSAP ssap) {
		ssapRepository.save(ssap);
	}

	public void updateSSAP(SSAP ssap){
		saveSSAP(ssap);
	}

	public void deleteSSAPById(Long id){
		ssapRepository.delete(id);
	}

	public void deleteAllSSAPs(){
		ssapRepository.deleteAll();
	}

	public List<SSAP> findAllSSAPs(){
		return ssapRepository.findAll(sortByIdAscDesc());
	}

	public List<Message> getMessages(){
		return messageRepository.findAll();
	}
	
	public boolean isSSAPExist(SSAP ssap) {
		return findByName(ssap.getName()) != null;
	}
	
	private Sort sortByIdAscDesc() {
        return new Sort(Sort.Direction.DESC, "ssapScore");
    }

	
}
