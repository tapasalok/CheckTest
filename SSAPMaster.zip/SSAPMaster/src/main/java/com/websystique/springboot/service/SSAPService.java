package com.websystique.springboot.service;

import com.websystique.springboot.model.SSAP;
import com.websystique.springboot.model.Message;

import java.util.List;

public interface SSAPService {

	SSAP findById(Long id);

	SSAP findByName(String name);

	void saveSSAP(SSAP ssap);

	void updateSSAP(SSAP ssap);

	void deleteSSAPById(Long id);

	void deleteAllSSAPs();

	List<SSAP> findAllSSAPs();

	List<Message> getMessages();

	boolean isSSAPExist(SSAP ssap);
}