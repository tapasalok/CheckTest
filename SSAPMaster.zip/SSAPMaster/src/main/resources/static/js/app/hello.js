angular.module('demo', [])
.controller("TimeSlotController", function($scope) {

    $scope.timeslots = timeslots;

});