'use strict';

angular.module('crudApp').factory('SSAPService',
    ['$localStorage', '$http', '$q', 'urls',
        function ($localStorage, $http, $q, urls) {

            var factory = {
                loadAllSSAPs: loadAllSSAPs,
                getAllSSAPs: getAllSSAPs,
                getAllMessages: getAllMessages,
                getMessages: getMessages,
                loadAllActiveSSAPs: loadAllActiveSSAPs,
                getAllActiveSSAPs: getAllActiveSSAPs,
                getSSAP: getSSAP,
                createSSAP: createSSAP,
                updateSSAP: updateSSAP,
                removeSSAP: removeSSAP
            };

            return factory;

            function loadAllSSAPs() {
                console.log('Fetching all SSAPs');
                var deferred = $q.defer();
                $http.get(urls.SSAP_SERVICE_API)
                    .then(
                        function (response) {
                            console.log('Fetched successfully all SSAPs');
                            $localStorage.ssaps = response.data;
                            deferred.resolve(response);
                        },
                        function (errResponse) {
                            console.error('Error while loading SSAPs');
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }
            
            function loadAllActiveSSAPs() {
                console.log('Fetching all Active SSAPs');
                var deferred = $q.defer();
                $http.get(urls.MARKET_ACTIVE_TIP_SERVICE_API)
                    .then(
                        function (response) {
                            console.log('Fetched successfully all Active SSAPs');
                            $localStorage.ssaps = response.data;
                            deferred.resolve(response);
                        },
                        function (errResponse) {
                            console.error('Error while loading Active SSAPs');
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function getAllSSAPs(){
                return $localStorage.ssaps;
            }
            
            function getAllMessages(){
            	 console.log('Fetching all Messages');
                 var deferred = $q.defer();
                 $http.get(urls.MESSAGES_SERVICE_API)
                     .then(
                         function (response) {
                             console.log('Fetched successfully all Messages');
                             $localStorage.messages = response.data;
                             deferred.resolve(response);
                         },
                         function (errResponse) {
                             console.error('Error while loading Messages');
                             deferred.reject(errResponse);
                         }
                     );
                 return deferred.promise;
            }
            
            function getMessages(){
                return $localStorage.messages;
            }
            
            function getAllActiveSSAPs(){
                return $localStorage.ssaps;
            }

            function getSSAP(id) {
                console.log('Fetching SSAP with id :'+id);
                var deferred = $q.defer();
                $http.get(urls.SSAP_SERVICE_API + id)
                    .then(
                        function (response) {
                            console.log('Fetched successfully SSAP with id :'+id);
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                            console.error('Error while loading SSAP with id :'+id);
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function createSSAP(ssap) {
                console.log('Creating SSAP');
                var deferred = $q.defer();
                $http.post(urls.SSAP_SERVICE_API, ssap)
                    .then(
                        function (response) {
                            loadAllSSAPs();
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                           console.error('Error while creating SSAP : '+errResponse.data.errorMessage);
                           deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function updateSSAP(ssap, id) {
                console.log('Updating SSAP with id '+id);
                var deferred = $q.defer();
                $http.put(urls.SSAP_SERVICE_API + id, ssap)
                    .then(
                        function (response) {
                            loadAllSSAPs();
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                            console.error('Error while updating SSAP with id :'+id);
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function removeSSAP(id) {
                console.log('Removing SSAP with id '+id);
                var deferred = $q.defer();
                $http.delete(urls.SSAP_SERVICE_API + id)
                    .then(
                        function (response) {
                            loadAllSSAPs();
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                            console.error('Error while removing SSAP with id :'+id);
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

        }
    ]);