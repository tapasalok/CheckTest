'use strict';

var app = angular.module('crudApp',['ui.router','ngStorage']);

app.constant('urls', {
	BASE: 'http://localhost:8080',
    SSAP_SERVICE_API : 'http://localhost:8080/api/ssap/',
    SSAP_ACTIVE_TIP_SERVICE_API : 'http://localhost:8080/api/ssap/',
    MESSAGES_SERVICE_API : 'http://localhost:8080/api/messages/',

});

app.config(['$stateProvider', '$urlRouterProvider',
    function($stateProvider, $urlRouterProvider) {
	    $stateProvider.state('home', {
                url: '/',
                templateUrl: '/partials/admin',
                controller:'SSAPController',
                controllerAs:'ctrl',
                resolve: {
                	ssaps: function ($q, SSAPService) {
                        console.log('Load all SSAPs');
                        var deferred = $q.defer();
                        SSAPService.loadAllSSAPs().then(deferred.resolve, deferred.resolve);
                        SSAPService.getAllMessages().then(deferred.resolve, deferred.resolve);
                        return deferred.promise;
                    }
                }
            }) ;
        $urlRouterProvider.otherwise('/');
    }]);