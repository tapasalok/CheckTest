'use strict';

angular.module('crudApp').controller('SSAPController',
    ['SSAPService', '$scope',  function( SSAPService, $scope) {

        var self = this;
        self.ssap = {};
        self.ssaps=[];

        self.submit = submit;
        self.getAllSSAPs = getAllSSAPs;
        self.getMessages = getMessages;
        self.getAllActiveSSAPs = getAllActiveSSAPs;
        self.createSSAP = createSSAP;
        self.updateSSAP = updateSSAP;
        self.removeSSAP = removeSSAP;
        self.editSSAP = editSSAP;
        self.reset = reset;

        self.successMessage = '';
        self.errorMessage = '';
        self.done = false;

        self.onlyIntegers = /^\d+$/;
        self.onlyNumbers = /^\d+([,.]\d+)?$/;

        function submit() {
            console.log('Submitting');
            if (self.ssap.id === undefined || self.ssap.id === null) {
                console.log('Saving New SSAP', self.ssap);
                createSSAP(self.ssap);
            } else {
                updateSSAP(self.ssap, self.ssap.id);
                console.log('SSAP updated with id ', self.ssap.id);
            }
        }

        function createSSAP(ssap) {
            console.log('About to create SSAP');
            SSAPService.createSSAP(ssap)
                .then(
                    function (response) {
                        console.log('SSAP inserted successfully');
                        self.successMessage = 'SSAP inserted successfully';
                        self.errorMessage='';
                        self.done = true;
                        self.ssap={};
                        $scope.myForm.$setPristine();
                    },
                    function (errResponse) {
                        console.error('Error while creating SSAP');
                        self.errorMessage = 'Error while creating SSAP: ' + errResponse.data.errorMessage;
                        self.successMessage='';
                    }
                );
        }


        function updateSSAP(ssap, id){
            console.log('About to update SSAP');
            SSAPService.updateSSAP(ssap, id)
                .then(
                    function (response){
                        console.log('SSAP updated successfully');
                        self.successMessage='SSAP updated successfully';
                        self.errorMessage='';
                        self.done = true;
                        $scope.myForm.$setPristine();
                    },
                    function(errResponse){
                        console.error('Error while updating SSAP');
                        self.errorMessage='Error while updating SSAP '+errResponse.data;
                        self.successMessage='';
                    }
                );
        }


        function removeSSAP(id){
            console.log('About to remove SSAP with id '+id);
            SSAPService.removeSSAP(id)
                .then(
                    function(){
                        console.log('SSAP '+id + ' removed successfully');
                    },
                    function(errResponse){
                        console.error('Error while removing SSAP '+id +', Error :'+errResponse.data);
                    }
                );
        }


        function getAllSSAPs(){
            return SSAPService.getAllSSAPs();
        }
        
        function getMessages(){
            return SSAPService.getMessages();
        }
        
        function getAllActiveSSAPs(){
            return SSAPService.getAllActiveSSAPs();
        }


        function editSSAP(id) {
            self.successMessage='';
            self.errorMessage='';
            SSAPService.getSSAP(id).then(
                function (ssap) {
                    self.ssap = ssap;
                },
                function (errResponse) {
                    console.error('Error while removing SSAP ' + id + ', Error :' + errResponse.data);
                }
            );
        }
        function reset(){
            self.successMessage='';
            self.errorMessage='';
            self.ssap={};
            $scope.myForm.$setPristine(); //reset Form
        }
    }


    ]);